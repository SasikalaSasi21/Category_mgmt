module.exports = {
  url : "mongodb+srv://sasikalas:Sasikala%402023@cluster0.ovlkr1i.mongodb.net/?retryWrites=true&w=majority"
}
